# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Amhage Technology Group LLC
# AeryxIQ 1.0.1 On-Premises Edition - start (and first-run setup).
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File .\up.ps1
#   powershell -ExecutionPolicy Bypass -File .\up.ps1 -WithDemoData
#   powershell -ExecutionPolicy Bypass -File .\up.ps1 -NoBrowser
#
# Written for Windows PowerShell 5.1, which ships with every supported
# Windows. Docker writes progress to stderr, which strict PowerShell reads
# as failure, so native commands run through cmd /c and exit codes are
# checked explicitly.
#
# What this does, in order, so that a first run on a fresh machine needs
# nothing from the operator but this one command:
#   1. finds Docker, starts Docker Desktop if it is installed but not
#      running, waits for the engine, and switches it to Linux containers
#   2. writes .env with fresh secrets on the first run
#   3. moves to free ports if 80 or 443 are already taken on this machine
#   4. pulls the images (with retries), starts, and waits for health
#   5. checks the HTTPS address end to end, opens it in the browser, and
#      offers to create the first administrator
param([switch]$WithDemoData, [switch]$NoBrowser)
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot

function New-Secret {
    param([int]$Bytes = 32)
    # Cryptographic randomness, not Get-Random. This value signs every
    # session token in the installation.
    $buf = New-Object byte[] $Bytes
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    $rng.GetBytes($buf)
    $rng.Dispose()
    # URL-safe, no padding: survives .env, YAML and shell quoting intact.
    [Convert]::ToBase64String($buf).Replace("+", "-").Replace("/", "_").Replace("=", "")
}

function Read-EnvMap {
    $map = @{}
    if (Test-Path ".env") {
        Get-Content ".env" | ForEach-Object {
            if ($_ -match '^\s*([A-Z0-9_]+)\s*=\s*(.*)$') { $map[$matches[1]] = $matches[2].Trim() }
        }
    }
    $map
}

function Set-EnvValue {
    param([string]$Key, [string]$Value)
    $lines = @(Get-Content ".env")
    $found = $false
    $out = foreach ($line in $lines) {
        if ($line -match "^\s*$Key\s*=") { $found = $true; "$Key=$Value" } else { $line }
    }
    if (-not $found) { $out = @($out) + "$Key=$Value" }
    # ascii on purpose: see the note where .env is first written.
    $out | Set-Content ".env" -Encoding ascii
}

function Test-PortFree {
    param([int]$Port)
    # Docker Desktop publishes container ports on every address, so the
    # question is whether anything already listens on any of them.
    foreach ($addr in @([System.Net.IPAddress]::Any, [System.Net.IPAddress]::Loopback)) {
        try {
            $l = New-Object System.Net.Sockets.TcpListener($addr, $Port)
            $l.ExclusiveAddressUse = $true
            $l.Start(); $l.Stop()
        } catch { return $false }
    }
    return $true
}

function Find-FreePort {
    param([int[]]$Candidates)
    foreach ($p in $Candidates) { if (Test-PortFree $p) { return $p } }
    return 0
}

function Invoke-Quiet {
    param([string]$Command)
    # Runs a native command, returns its combined output, sets $LASTEXITCODE.
    $out = cmd /c "$Command 2>&1"
    ($out | Out-String).Trim()
}

Write-Host ""
Write-Host "AeryxIQ 1.0.1 On-Premises Edition" -ForegroundColor Cyan
Write-Host ""

# ---------------------------------------------------------------- Docker
$dockerDir = Join-Path $env:ProgramFiles "Docker\Docker"
$desktopExe = Join-Path $dockerDir "Docker Desktop.exe"
$dockerCli = Join-Path $dockerDir "DockerCli.exe"
$dockerBin = Join-Path $dockerDir "resources\bin"

# A PowerShell window opened before Docker Desktop was installed, or one
# started by an installer, can have a PATH without Docker on it. Docker is
# still there; add its folder for this run rather than calling it missing.
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    if (Test-Path (Join-Path $dockerBin "docker.exe")) {
        $env:Path = "$dockerBin;$env:Path"
    }
}
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Write-Host "Docker Desktop is not installed on this machine." -ForegroundColor Red
    Write-Host ""
    Write-Host "AeryxIQ runs as Docker containers. Install Docker Desktop (free for"
    Write-Host "personal use and small businesses), start it once, then run this again."
    Write-Host ""
    Write-Host "  https://www.docker.com/products/docker-desktop/"
    if (-not $NoBrowser) { Start-Process "https://www.docker.com/products/docker-desktop/" }
    exit 1
}

$info = Invoke-Quiet "docker info --format {{.OSType}}"
if ($LASTEXITCODE -ne 0) {
    Write-Host "Docker says: $info" -ForegroundColor DarkGray
    # Waiting will not fix a permissions problem. Say so now, not in five minutes.
    if ($info -match "Access is denied|permission denied") {
        Write-Host ""
        Write-Host "This Windows account is not allowed to use Docker." -ForegroundColor Red
        Write-Host "In an administrator PowerShell run:"
        Write-Host "  net localgroup docker-users `"$env:USERDOMAIN\$env:USERNAME`" /add"
        Write-Host "then sign out of Windows, sign back in, and run this again."
        exit 1
    }
    $running = Get-Process -Name "Docker Desktop" -ErrorAction SilentlyContinue
    if (-not $running -and (Test-Path $desktopExe)) {
        Write-Host "Starting Docker Desktop..." -ForegroundColor Cyan
        Start-Process $desktopExe
    } else {
        Write-Host "Waiting for the Docker engine to finish starting..." -ForegroundColor Cyan
    }
    # Docker Desktop takes from a few seconds to a few minutes to bring its
    # engine up, longer on the first start after a reboot or an update.
    $deadline = (Get-Date).AddMinutes(5)
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Seconds 5
        Write-Host "." -NoNewline
        $info = Invoke-Quiet "docker info --format {{.OSType}}"
        if ($LASTEXITCODE -eq 0) { break }
    }
    Write-Host ""
    if ($LASTEXITCODE -ne 0) {
        Write-Host "The Docker engine did not start within five minutes." -ForegroundColor Red
        Write-Host ""
        Write-Host "What Docker said:" -ForegroundColor Yellow
        Write-Host "  $info"
        Write-Host ""
        Write-Host "Open Docker Desktop and look at the status in its bottom-left corner."
        Write-Host "It has to read 'Engine running'. If it asks you to accept terms,"
        Write-Host "sign in, or finish installing WSL, do that, then run this again."
        exit 1
    }
}

# AeryxIQ's images are Linux images. Docker Desktop can be switched to
# Windows containers, in which case nothing would pull.
if ($info -match "windows") {
    Write-Host "Docker is in Windows containers mode. Switching to Linux containers..." -ForegroundColor Cyan
    if (Test-Path $dockerCli) { & $dockerCli -SwitchLinuxEngine | Out-Null }
    $deadline = (Get-Date).AddMinutes(3)
    do {
        Start-Sleep -Seconds 5
        $info = Invoke-Quiet "docker info --format {{.OSType}}"
    } while (($info -notmatch "linux") -and ((Get-Date) -lt $deadline))
    if ($info -notmatch "linux") {
        Write-Host "Could not switch Docker to Linux containers." -ForegroundColor Red
        Write-Host "Right-click the Docker icon by the clock and choose"
        Write-Host "'Switch to Linux containers...', then run this again."
        exit 1
    }
}

$null = Invoke-Quiet "docker compose version"
if ($LASTEXITCODE -ne 0) {
    Write-Host "This Docker has no 'docker compose'. Update Docker Desktop, then run this again." -ForegroundColor Red
    exit 1
}
Write-Host "Docker is running." -ForegroundColor Green

# ------------------------------------------------------------ First run
if (-not (Test-Path ".env")) {
    Write-Host "First run. Creating .env and generating secrets." -ForegroundColor Cyan
    $lines = Get-Content "env.example"
    $out = foreach ($line in $lines) {
        if ($line -match '^POSTGRES_PASSWORD=') { "POSTGRES_PASSWORD=" + (New-Secret 24) }
        elseif ($line -match '^JWT_SECRET=')    { "JWT_SECRET=" + (New-Secret 48) }
        else { $line }
    }
    # ascii on purpose. Set-Content -Encoding UTF8 on PowerShell 5.1 writes
    # a byte-order mark, and a BOM on the first line of a .env file makes
    # Docker Compose read the first key name with three invisible bytes
    # glued to the front of it.
    $out | Set-Content ".env" -Encoding ascii
    Write-Host "  .env written. Keep it: it holds the database password and" -ForegroundColor Yellow
    Write-Host "  the token signing key for this installation." -ForegroundColor Yellow
    Write-Host ""
}

# --------------------------------------------------------- Version
# A newer bundle carries a newer AERYXIQ_VERSION in env.example. Raise the
# value in .env to match, so running a newer up upgrades the installation.
# Never lower it: a version set by hand stays.
$bundleVersion = ((Get-Content "env.example" | Where-Object { $_ -match '^AERYXIQ_VERSION=' } | Select-Object -First 1) -replace '^AERYXIQ_VERSION=','').Trim()
$currentVersion = (Read-EnvMap)["AERYXIQ_VERSION"]
$raise = $false
if ($bundleVersion) {
    if (-not $currentVersion) { $raise = $true }
    else {
        try { $raise = ([version]$bundleVersion -gt [version]$currentVersion) } catch { $raise = $false }
    }
}
if ($raise) {
    Set-EnvValue "AERYXIQ_VERSION" $bundleVersion
    if ($currentVersion) { Write-Host "Upgrading AeryxIQ from $currentVersion to $bundleVersion." -ForegroundColor Cyan }
}

# ----------------------------------------------------------------- Ports
# If AeryxIQ is already running, its own proxy holds the ports and that is
# fine. Otherwise anything else on 80 or 443 (IIS, Skype, another local
# web app) would make the start fail, so move to the next free port and
# record it in .env, where it stays for every later start.
$caddyUp = Invoke-Quiet "docker compose ps --status running -q caddy"
if (-not $caddyUp) {
    $envmap = Read-EnvMap
    $https = 443; if ($envmap["HTTPS_PORT"]) { $https = [int]$envmap["HTTPS_PORT"] }
    $http = 80;   if ($envmap["HTTP_PORT"])  { $http  = [int]$envmap["HTTP_PORT"] }
    if (-not (Test-PortFree $https)) {
        $new = Find-FreePort @(8443, 9443, 10443, 11443, 12443)
        if ($new -eq 0) {
            Write-Host "Port $https and the usual alternatives are all in use." -ForegroundColor Red
            Write-Host "Set HTTPS_PORT in .env to a free port and run this again."
            exit 1
        }
        Write-Host "Port $https is already in use on this machine. AeryxIQ will use $new." -ForegroundColor Yellow
        Set-EnvValue "HTTPS_PORT" "$new"
    }
    if (-not (Test-PortFree $http)) {
        $new = Find-FreePort @(8080, 8081, 9080, 10080, 11080)
        if ($new -eq 0) {
            Write-Host "Port $http and the usual alternatives are all in use." -ForegroundColor Red
            Write-Host "Set HTTP_PORT in .env to a free port and run this again."
            exit 1
        }
        Write-Host "Port $http is already in use on this machine. AeryxIQ will use $new." -ForegroundColor Yellow
        Set-EnvValue "HTTP_PORT" "$new"
    }
}

$envmap = Read-EnvMap
$host_name = $envmap["APP_HOST"]
if (-not $host_name) { $host_name = "aeryxiq.localhost" }
$port = $envmap["HTTPS_PORT"]
if (-not $port) { $port = "443" }
$url = "https://$host_name"
if ($port -ne "443") { $url = "https://${host_name}:$port" }

# ------------------------------------------------------------ Pull, start
Write-Host "Downloading the AeryxIQ images (first run only, a few minutes)..." -ForegroundColor Cyan
$pulled = $false
foreach ($attempt in 1..3) {
    cmd /c "docker compose pull"
    if ($LASTEXITCODE -eq 0) { $pulled = $true; break }
    if ($attempt -lt 3) {
        Write-Host "Download interrupted. Retrying in 15 seconds ($attempt of 3)..." -ForegroundColor Yellow
        Start-Sleep -Seconds 15
    }
}
if (-not $pulled) {
    Write-Host ""
    Write-Host "Could not download the images." -ForegroundColor Red
    Write-Host "This machine needs outbound access to ghcr.io and Docker Hub for the"
    Write-Host "install only. For a site with no internet at all, see the offline"
    Write-Host "install section of the Installation Guide."
    exit 1
}

Write-Host "Starting..." -ForegroundColor Cyan
cmd /c "docker compose up -d"
if ($LASTEXITCODE -ne 0) {
    Write-Host "Start failed. See: docker compose logs" -ForegroundColor Red
    exit 1
}

Write-Host "Waiting for the application..." -ForegroundColor Cyan
$probe = "import urllib.request,sys" + [char]10 + "sys.exit(0 if urllib.request.urlopen('http://localhost:8000/healthz',timeout=3).status==200 else 1)"
$ready = $false
foreach ($i in 1..90) {
    cmd /c "docker compose exec -T backend python -c ""$probe"" >nul 2>&1"
    if ($LASTEXITCODE -eq 0) { $ready = $true; break }
    Start-Sleep -Seconds 2
}
if (-not $ready) {
    Write-Host "The application did not report healthy within three minutes." -ForegroundColor Red
    Write-Host "See: docker compose logs backend"
    exit 1
}

# The backend answering is not the whole chain. Check the address the
# operator will actually open, through the HTTPS proxy and the web server.
# curl.exe ships with Windows 10 1803 and later; skip the check without it.
$curl = Join-Path $env:SystemRoot "System32\curl.exe"
if (Test-Path $curl) {
    $ok = $false
    foreach ($i in 1..20) {
        $code = & $curl -sk -o NUL -w "%{http_code}" --resolve "${host_name}:${port}:127.0.0.1" "https://${host_name}:${port}/healthz" 2>$null
        if ($code -eq "200") { $ok = $true; break }
        Start-Sleep -Seconds 2
    }
    if (-not $ok) {
        Write-Host "The application is up but $url does not answer yet." -ForegroundColor Yellow
        Write-Host "Give it a minute and refresh. If it persists: docker compose logs caddy"
    }
}

if ($WithDemoData) {
    Write-Host "Loading demo data..." -ForegroundColor Cyan
    cmd /c "docker compose exec -T backend python -m app.seed"
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Demo data did not load. The installation is still fine." -ForegroundColor Yellow
    }
}

# A shortcut that always points at this installation's real address, ports
# included. The Start Menu entry "Open AeryxIQ" opens it through open.ps1.
"[InternetShortcut]`r`nURL=$url`r`n" | Set-Content "Open AeryxIQ.url" -Encoding ascii

Write-Host ""
Write-Host "AeryxIQ is running." -ForegroundColor Green
Write-Host ""
Write-Host "  $url" -ForegroundColor White
Write-Host ""
Write-Host "The first visit shows a certificate warning. That is expected:"
Write-Host "this installation signs its own certificate so that nothing has to"
Write-Host "be requested from the internet. Run .\trust-certificate.ps1 as an"
Write-Host "administrator to remove the warning on this machine."
Write-Host ""

# ------------------------------------------------- First administrator
if ($WithDemoData) {
    Write-Host "  Demo sign-in:  Company ID amhage  /  Email admin@example.com  /  Password aeryx-demo" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Demo data is sample content. Create your own organisation with"
    Write-Host ".\new-admin.ps1 before putting real flights in."
} else {
    # One line, and the answer behind a marker: whatever Docker or Python
    # prints around it (warnings, notices), the count is found by name.
    $countPy = "from app.db import Base,SessionLocal,engine; from app.models import User; Base.metadata.create_all(bind=engine); print('AERYX_USERS='+str(SessionLocal().query(User).count()))"
    $raw = Invoke-Quiet "docker compose exec -T backend python -c ""$countPy"""
    $users = ""
    if ($raw -match 'AERYX_USERS=(\d+)') { $users = $matches[1] }
    if ($users -eq "0") {
        Write-Host "No administrator exists yet." -ForegroundColor Yellow
        $answer = Read-Host "Create one now? [Y/n]"
        if ($answer -notmatch '^[nN]') {
            & (Join-Path $PSScriptRoot "new-admin.ps1")
        } else {
            Write-Host "Later:  powershell -ExecutionPolicy Bypass -File .\new-admin.ps1"
        }
    } elseif ($users -match '^\d+$') {
        Write-Host "Sign in with your Company ID, email and password."
    } else {
        # Could not tell. Offering is harmless: new-admin creates the
        # organisation and administrator, or resets an existing one.
        $answer = Read-Host "Create or reset an administrator now? [Y/n]"
        if ($answer -notmatch '^[nN]') {
            & (Join-Path $PSScriptRoot "new-admin.ps1")
        } else {
            Write-Host "Later:  powershell -ExecutionPolicy Bypass -File .\new-admin.ps1"
        }
    }
}
Write-Host ""
if (-not $NoBrowser) { Start-Process $url }
