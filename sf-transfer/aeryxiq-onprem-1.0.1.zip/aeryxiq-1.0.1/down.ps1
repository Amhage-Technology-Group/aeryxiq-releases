# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Amhage Technology Group LLC
# Stop AeryxIQ. Flights, imagery and reports are untouched: they live in
# Docker volumes that outlive the containers.
#
#   powershell -ExecutionPolicy Bypass -File .\down.ps1
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot
cmd /c "docker compose down"
Write-Host ""
Write-Host "AeryxIQ stopped. Data kept. Start again with .\up.ps1" -ForegroundColor Cyan
Write-Host ""
Write-Host "To erase the data as well - every flight, image and report -" -ForegroundColor Yellow
Write-Host "run: docker compose down -v" -ForegroundColor Yellow
