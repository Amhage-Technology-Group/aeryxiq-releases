#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Amhage Technology Group LLC
# Stop AeryxIQ. Flights, imagery and reports are untouched: they live in
# Docker volumes that outlive the containers.
set -euo pipefail
cd "$(dirname "$0")"
if docker compose version >/dev/null 2>&1; then docker compose down; else docker-compose down; fi
echo
echo "AeryxIQ stopped. Data kept. Start again with ./up.sh"
echo
echo "To erase the data as well - every flight, image and report -"
echo "run: docker compose down -v"
