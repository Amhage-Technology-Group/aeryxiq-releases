# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Amhage Technology Group LLC
# Report what is running and whether the application answers.
#
#   powershell -ExecutionPolicy Bypass -File .\health.ps1
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot

Write-Host ""
Write-Host "Containers" -ForegroundColor Cyan
cmd /c "docker compose ps"

Write-Host ""
Write-Host "Application" -ForegroundColor Cyan
$probe = "import urllib.request,sys" + [char]10 + "r=urllib.request.urlopen('http://localhost:8000/healthz',timeout=3)" + [char]10 + "print(r.read().decode()[:200])"
cmd /c "docker compose exec -T backend python -c ""$probe"""
if ($LASTEXITCODE -ne 0) {
    Write-Host "  the API did not answer" -ForegroundColor Red
    Write-Host "  see: docker compose logs backend"
}

Write-Host ""
Write-Host "Database" -ForegroundColor Cyan
cmd /c "docker compose exec -T postgres pg_isready -U aeryxiq"

Write-Host ""
Write-Host "Disk used by AeryxIQ volumes" -ForegroundColor Cyan
cmd /c "docker system df -v" | Select-String "aeryxiq_onprem"
Write-Host ""
