# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Amhage Technology Group LLC
# Create an administrator, or reset an existing one's password.
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File .\new-admin.ps1
#   powershell -ExecutionPolicy Bypass -File .\new-admin.ps1 -Slug acme -Email you@acme.com
#
# The sign-in page asks for Company ID, Email and Password. The Company ID
# (the organisation's slug) names your organisation and
# keeps one installation able to hold several of them without their flights
# ever being visible to each other.
param(
    [string]$Slug = "",
    [string]$Email = "",
    [string]$OrgName = "",
    [string]$FullName = "Administrator"
)
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot

if (-not $Slug)  { $Slug  = Read-Host "Company ID (short, lowercase, no spaces, e.g. acme)" }
if (-not $Email) { $Email = Read-Host "Administrator email address" }
if (-not $OrgName) { $OrgName = Read-Host "Company display name (blank to use the Company ID)" }

$secure = Read-Host -AsSecureString "Password for $Email"
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
$plain = [Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)

if ($plain.Length -lt 12) {
    Write-Host "That password is under 12 characters. Pick a longer one." -ForegroundColor Red
    exit 1
}

# The values travel as environment variables, never spliced into the
# Python source. A password containing a quote, a backslash or a newline
# would otherwise either break the script or silently truncate the
# password that actually gets stored.
$py = @'
import os, sys
from sqlalchemy import select
from app.db import Base, SessionLocal, engine
from app.models import Organization, User
from app.security import hash_password

slug = os.environ["AERYX_SLUG"].strip().lower()
email = os.environ["AERYX_EMAIL"].strip().lower()
org_name = os.environ.get("AERYX_ORG", "").strip() or slug.title()
full_name = os.environ.get("AERYX_NAME", "Administrator").strip()
password = os.environ["AERYX_PW"]

Base.metadata.create_all(bind=engine)
db = SessionLocal()
org = db.scalar(select(Organization).where(Organization.slug == slug))
created_org = False
if org is None:
    org = Organization(slug=slug, name=org_name)
    db.add(org)
    db.flush()
    created_org = True

user = db.scalar(select(User).where(User.org_id == org.id, User.email == email))
if user is not None:
    user.password_hash = hash_password(password)
    user.role = "admin"
    user.is_active = True
    action = "password reset"
else:
    db.add(User(org_id=org.id, email=email, full_name=full_name,
                role="admin", password_hash=hash_password(password)))
    action = "administrator created"
db.commit()

print("organisation created: " + slug if created_org else "organisation found: " + slug)
print(action + ": " + email)
print("")
print("Sign in with:")
print("  Company ID: " + slug)
print("  Email:      " + email)
print("  Password:   the one you just set")
'@

$tmp = Join-Path $env:TEMP ("aeryx-admin-" + [Guid]::NewGuid().ToString("N") + ".py")
try {
    $py | Set-Content $tmp -Encoding ascii
    $env:AERYX_SLUG = $Slug
    $env:AERYX_EMAIL = $Email
    $env:AERYX_ORG = $OrgName
    $env:AERYX_NAME = $FullName
    $env:AERYX_PW = $plain
    Get-Content $tmp -Raw | cmd /c "docker compose exec -T -e AERYX_SLUG -e AERYX_EMAIL -e AERYX_ORG -e AERYX_NAME -e AERYX_PW backend python -"
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Could not create the administrator. Is AeryxIQ running? Try .\up.ps1" -ForegroundColor Red
        exit 1
    }
} finally {
    Remove-Item $tmp -ErrorAction SilentlyContinue
    $env:AERYX_PW = $null
    $plain = $null
}
Write-Host ""
Write-Host "Done." -ForegroundColor Green
