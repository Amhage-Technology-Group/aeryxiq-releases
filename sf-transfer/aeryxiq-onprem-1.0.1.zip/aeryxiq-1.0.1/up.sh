#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Amhage Technology Group LLC
# AeryxIQ 1.0.1 On-Premises Edition - start (and first-run setup).
# Finds Docker and waits for it, writes .env on the first run, moves off
# ports 80/443 if they are taken, pulls with retries, and checks the HTTPS
# address end to end before reporting success.
#
#   ./up.sh                 start
#   ./up.sh --with-demo     start and load sample content
set -euo pipefail
cd "$(dirname "$0")"

demo=0
for arg in "$@"; do
  case "$arg" in
    --with-demo) demo=1 ;;
    *) echo "unknown option: $arg" >&2; exit 2 ;;
  esac
done

compose() {
  if docker compose version >/dev/null 2>&1; then docker compose "$@"
  elif command -v docker-compose >/dev/null 2>&1; then docker-compose "$@"
  else echo "Docker Compose is not installed." >&2; exit 1
  fi
}

echo
echo "AeryxIQ 1.0.1 On-Premises Edition"
echo

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker is not installed. Install Docker Desktop (macOS) or Docker Engine" >&2
  echo "(Linux): https://docs.docker.com/get-docker/  then run this again." >&2
  exit 1
fi

if ! docker info >/dev/null 2>&1; then
  # macOS: Docker Desktop installed but not started. Start it and wait.
  if [ "$(uname -s)" = "Darwin" ] && [ -d /Applications/Docker.app ]; then
    echo "Starting Docker Desktop..."
    open -a Docker || true
  else
    echo "Waiting for the Docker engine..."
  fi
  for _ in $(seq 1 60); do
    docker info >/dev/null 2>&1 && break
    printf '.'
    sleep 5
  done
  echo
fi
if ! docker info >/dev/null 2>&1; then
  echo "Docker is not running, or this user cannot reach it." >&2
  echo "What Docker said:" >&2
  docker info 2>&1 | tail -n 3 >&2 || true
  echo "On Linux that is usually: sudo systemctl start docker, or" >&2
  echo "sudo usermod -aG docker \$USER, then log out and back in." >&2
  exit 1
fi

if [ ! -f .env ]; then
  echo "First run. Creating .env and generating secrets."
  # URL-safe base64 from the kernel's random device. No padding, so the
  # value survives .env, YAML and shell quoting untouched.
  secret() { head -c "$1" /dev/urandom | base64 | tr '+/' '-_' | tr -d '=\n'; }
  pg=$(secret 24)
  jwt=$(secret 48)
  while IFS= read -r line; do
    case "$line" in
      POSTGRES_PASSWORD=*) printf 'POSTGRES_PASSWORD=%s\n' "$pg" ;;
      JWT_SECRET=*)        printf 'JWT_SECRET=%s\n' "$jwt" ;;
      *)                   printf '%s\n' "$line" ;;
    esac
  done < env.example > .env
  chmod 600 .env
  echo "  .env written, readable only by this user. Keep it: it holds the"
  echo "  database password and the token signing key for this installation."
  echo
fi

# A newer bundle carries a newer AERYXIQ_VERSION in env.example. Raise the
# value in .env to match, so running a newer up upgrades the installation.
# Never lower it: a version set by hand stays.
bundle_version=$(grep -E '^AERYXIQ_VERSION=' env.example | head -n1 | cut -d= -f2- | tr -d '[:space:]' || true)
current_version=$(grep -E '^AERYXIQ_VERSION=' .env | head -n1 | cut -d= -f2- | tr -d '[:space:]' || true)
if [ -n "$bundle_version" ] && { [ -z "$current_version" ] || \
     [ "$(printf '%s\n%s\n' "$current_version" "$bundle_version" | sort -t. -k1,1n -k2,2n -k3,3n | tail -n1)" = "$bundle_version" ] && \
     [ "$current_version" != "$bundle_version" ]; }; then
  if grep -qE '^AERYXIQ_VERSION=' .env; then
    tmp=$(mktemp); sed -E "s|^AERYXIQ_VERSION=.*|AERYXIQ_VERSION=$bundle_version|" .env > "$tmp" && cat "$tmp" > .env && rm -f "$tmp"
  else
    printf 'AERYXIQ_VERSION=%s\n' "$bundle_version" >> .env
  fi
  [ -n "$current_version" ] && echo "Upgrading AeryxIQ from $current_version to $bundle_version."
fi

# If 80 or 443 are already taken by something else, move to the next free
# port and record it in .env. Skipped when AeryxIQ's own proxy is the one
# holding them.
port_busy() { (exec 3<>"/dev/tcp/127.0.0.1/$1") >/dev/null 2>&1; }
set_env() {
  if grep -qE "^$1=" .env; then
    tmp=$(mktemp); sed -E "s|^$1=.*|$1=$2|" .env > "$tmp" && cat "$tmp" > .env && rm -f "$tmp"
  else
    printf '%s=%s\n' "$1" "$2" >> .env
  fi
}
if [ -z "$(compose ps --status running -q caddy 2>/dev/null || true)" ]; then
  hp=$(grep -E '^HTTPS_PORT=' .env | cut -d= -f2- | tr -d '[:space:]' || true); hp=${hp:-443}
  pp=$(grep -E '^HTTP_PORT=' .env | cut -d= -f2- | tr -d '[:space:]' || true); pp=${pp:-80}
  if port_busy "$hp"; then
    for c in 8443 9443 10443 11443 12443; do
      if ! port_busy "$c"; then echo "Port $hp is in use on this machine. AeryxIQ will use $c."; set_env HTTPS_PORT "$c"; break; fi
    done
  fi
  if port_busy "$pp"; then
    for c in 8080 8081 9080 10080 11080; do
      if ! port_busy "$c"; then echo "Port $pp is in use on this machine. AeryxIQ will use $c."; set_env HTTP_PORT "$c"; break; fi
    done
  fi
fi

echo "Downloading the AeryxIQ images (first run only, a few minutes)..."
pulled=0
for attempt in 1 2 3; do
  if compose pull; then pulled=1; break; fi
  [ "$attempt" -lt 3 ] && { echo "Download interrupted. Retrying in 15 seconds ($attempt of 3)..."; sleep 15; }
done
if [ "$pulled" -ne 1 ]; then
  echo >&2
  echo "Could not download the images. This machine needs outbound access to" >&2
  echo "ghcr.io for the install only. For a site with no internet at all, see" >&2
  echo "the offline install section of the Installation Guide." >&2
  exit 1
fi

echo "Starting..."
compose up -d

echo "Waiting for the application..."
ready=0
for _ in $(seq 1 90); do
  if compose exec -T backend python -c \
     "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://localhost:8000/healthz',timeout=3).status==200 else 1)" \
     >/dev/null 2>&1; then
    ready=1
    break
  fi
  sleep 2
done
if [ "$ready" -ne 1 ]; then
  echo "The application did not report healthy within three minutes." >&2
  echo "See: docker compose logs backend" >&2
  exit 1
fi

# `|| true` on both: under `set -e` a grep that matches nothing would end
# the script here, after a successful install, with no explanation.
app_host=$(grep -E '^APP_HOST=' .env | cut -d= -f2- | tr -d '[:space:]' || true)
[ -n "$app_host" ] || app_host=aeryxiq.localhost
https_port=$(grep -E '^HTTPS_PORT=' .env | cut -d= -f2- | tr -d '[:space:]' || true)
url="https://$app_host"
if [ -n "$https_port" ] && [ "$https_port" != "443" ]; then
  url="https://$app_host:$https_port"
fi

if command -v curl >/dev/null 2>&1; then
  hp=${https_port:-443}
  ok=0
  for _ in $(seq 1 20); do
    code=$(curl -sk -o /dev/null -w '%{http_code}' --resolve "$app_host:$hp:127.0.0.1" "https://$app_host:$hp/healthz" || true)
    [ "$code" = "200" ] && { ok=1; break; }
    sleep 2
  done
  [ "$ok" -eq 1 ] || echo "The application is up but $url does not answer yet. Give it a minute; if it persists: docker compose logs caddy" >&2
fi

if [ "$demo" -eq 1 ]; then
  echo "Loading demo data..."
  compose exec -T backend python -m app.seed || \
    echo "Demo data did not load. The installation is still fine." >&2
fi

echo
echo "AeryxIQ is running."
echo
echo "  $url"
echo
echo "The first visit shows a certificate warning. That is expected: this"
echo "installation signs its own certificate so nothing has to be requested"
echo "from the internet. ./trust-certificate.sh explains how to remove the"
echo "warning on this machine."
echo
if [ "$demo" -eq 1 ]; then
  echo "  Demo sign-in:  Company ID amhage  /  Email admin@example.com  /  Password aeryx-demo"
  echo
  echo "Demo data is sample content. Create your own organisation with"
  echo "./new-admin.sh before putting real flights in."
else
  echo "Create your first administrator:  ./new-admin.sh"
fi
echo
