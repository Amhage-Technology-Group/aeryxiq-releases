# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Amhage Technology Group LLC
# Open AeryxIQ in the default browser at this installation's real address,
# including a non-standard port if up.ps1 had to move off 443.
#
#   powershell -ExecutionPolicy Bypass -File .\open.ps1
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot
$map = @{}
if (Test-Path ".env") {
    Get-Content ".env" | ForEach-Object {
        if ($_ -match '^\s*([A-Z0-9_]+)\s*=\s*(.*)$') { $map[$matches[1]] = $matches[2].Trim() }
    }
}
$h = $map["APP_HOST"]; if (-not $h) { $h = "aeryxiq.localhost" }
$p = $map["HTTPS_PORT"]; if (-not $p) { $p = "443" }
$url = "https://$h"; if ($p -ne "443") { $url = "https://${h}:$p" }
Start-Process $url
