#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Amhage Technology Group LLC
# Report what is running and whether the application answers.
set -uo pipefail
cd "$(dirname "$0")"
compose() {
  if docker compose version >/dev/null 2>&1; then docker compose "$@"; else docker-compose "$@"; fi
}

echo
echo "Containers"
compose ps

echo
echo "Application"
if ! compose exec -T backend python -c \
   "import urllib.request; print(urllib.request.urlopen('http://localhost:8000/healthz',timeout=3).read().decode()[:200])"; then
  echo "  the API did not answer"
  echo "  see: docker compose logs backend"
fi

echo
echo "Database"
compose exec -T postgres pg_isready -U aeryxiq || true

echo
echo "Disk used by AeryxIQ volumes"
docker system df -v 2>/dev/null | grep aeryxiq_onprem || echo "  (none reported)"
echo
