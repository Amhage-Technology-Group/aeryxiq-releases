# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Amhage Technology Group LLC
# Back up this installation to a folder you choose.
#
#   powershell -ExecutionPolicy Bypass -File .\backup.ps1 -To D:\Backups
#
# Writes three files, timestamped: the database, the imagery, and a copy
# of .env. All three are needed to restore. .env holds the token signing
# key and the database password, so the destination folder deserves the
# same care as the imagery itself.
param([Parameter(Mandatory)] [string]$To)
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot

if (-not (Test-Path $To)) { New-Item -ItemType Directory -Path $To -Force | Out-Null }
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$dest = (Resolve-Path $To).Path

Write-Host "Database..." -ForegroundColor Cyan
$dump = Join-Path $dest "aeryxiq-db-$stamp.sql"
cmd /c "docker compose exec -T postgres pg_dump -U aeryxiq aeryxiq > ""$dump"""
if (($LASTEXITCODE -ne 0) -or (-not (Test-Path $dump)) -or ((Get-Item $dump).Length -lt 1024)) {
    Write-Host "The database dump failed or came back empty. Nothing was backed up." -ForegroundColor Red
    exit 1
}
Write-Host ("  " + [math]::Round((Get-Item $dump).Length / 1MB, 1) + " MB")

Write-Host "Imagery..." -ForegroundColor Cyan
$media = Join-Path $dest "aeryxiq-media-$stamp.tar.gz"
cmd /c "docker run --rm -v aeryxiq_onprem_media_data:/media_data:ro -v ""$dest"":/out alpine tar czf ""/out/aeryxiq-media-$stamp.tar.gz"" -C /media_data ."
if (($LASTEXITCODE -ne 0) -or (-not (Test-Path $media))) {
    Write-Host "The imagery archive failed. The database dump above is still good," -ForegroundColor Red
    Write-Host "but it is not a complete backup on its own." -ForegroundColor Red
    exit 1
}
Write-Host ("  " + [math]::Round((Get-Item $media).Length / 1MB, 1) + " MB")

Copy-Item ".env" (Join-Path $dest "aeryxiq-env-$stamp.txt") -Force

Write-Host ""
Write-Host "Backed up to $dest" -ForegroundColor Green
Write-Host "  aeryxiq-db-$stamp.sql"
Write-Host "  aeryxiq-media-$stamp.tar.gz"
Write-Host "  aeryxiq-env-$stamp.txt"
Write-Host ""
Write-Host "A backup nobody has restored is a hope, not a backup. The"
Write-Host "Administrator Guide has the restore procedure; run it once now,"
Write-Host "on a spare machine, while there is nothing at stake."
