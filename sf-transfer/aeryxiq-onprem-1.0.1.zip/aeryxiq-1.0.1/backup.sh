#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Amhage Technology Group LLC
# Back up this installation to a directory you choose.
#
#   ./backup.sh /backups/aeryxiq
#
# Writes three files, timestamped: the database, the imagery, and a copy of
# .env. All three are needed to restore. .env holds the token signing key
# and the database password, so the destination deserves the same care as
# the imagery itself.
set -euo pipefail
cd "$(dirname "$0")"

dest="${1:-}"
if [ -z "$dest" ]; then echo "usage: ./backup.sh <destination-directory>" >&2; exit 2; fi
mkdir -p "$dest"
dest=$(cd "$dest" && pwd)
stamp=$(date +%Y%m%d-%H%M%S)

compose() {
  if docker compose version >/dev/null 2>&1; then docker compose "$@"; else docker-compose "$@"; fi
}

echo "Database..."
dump="$dest/aeryxiq-db-$stamp.sql"
compose exec -T postgres pg_dump -U aeryxiq aeryxiq > "$dump"
if [ ! -s "$dump" ] || [ "$(wc -c < "$dump")" -lt 1024 ]; then
  echo "The database dump failed or came back empty. Nothing was backed up." >&2
  rm -f "$dump"
  exit 1
fi
echo "  $(du -h "$dump" | cut -f1)"

echo "Imagery..."
media="aeryxiq-media-$stamp.tar.gz"
docker run --rm \
  -v aeryxiq_onprem_media_data:/media_data:ro \
  -v "$dest":/out \
  alpine tar czf "/out/$media" -C /media_data .
if [ ! -s "$dest/$media" ]; then
  echo "The imagery archive failed. The database dump above is still good," >&2
  echo "but it is not a complete backup on its own." >&2
  exit 1
fi
echo "  $(du -h "$dest/$media" | cut -f1)"

install -m 600 .env "$dest/aeryxiq-env-$stamp.txt"

echo
echo "Backed up to $dest"
echo "  aeryxiq-db-$stamp.sql"
echo "  $media"
echo "  aeryxiq-env-$stamp.txt"
echo
echo "A backup nobody has restored is a hope, not a backup. The Administrator"
echo "Guide has the restore procedure; run it once now, on a spare machine,"
echo "while there is nothing at stake."
