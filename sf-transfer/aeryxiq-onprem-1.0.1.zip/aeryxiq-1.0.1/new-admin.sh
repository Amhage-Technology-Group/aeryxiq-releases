#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Amhage Technology Group LLC
# Create an administrator, or reset an existing one's password.
#
#   ./new-admin.sh
#   ./new-admin.sh --slug acme --email you@acme.com --org "Acme Surveying"
#
# The sign-in page asks for Company ID, Email and Password. The Company ID
# (the organisation's slug) names your organisation and
# keeps one installation able to hold several of them without their flights
# ever being visible to each other.
set -euo pipefail
cd "$(dirname "$0")"

slug=""; email=""; org=""; name="Administrator"
while [ $# -gt 0 ]; do
  case "$1" in
    --slug)  slug="$2"; shift 2 ;;
    --email) email="$2"; shift 2 ;;
    --org)   org="$2"; shift 2 ;;
    --name)  name="$2"; shift 2 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
done

compose() {
  if docker compose version >/dev/null 2>&1; then docker compose "$@"
  else docker-compose "$@"
  fi
}

[ -n "$slug" ]  || read -r -p "Company ID (short, lowercase, no spaces, e.g. acme): " slug
[ -n "$email" ] || read -r -p "Administrator email address: " email
[ -n "$org" ]   || read -r -p "Company display name (blank to use the Company ID): " org

read -r -s -p "Password for $email: " pw; echo
read -r -s -p "Again: " pw2; echo
if [ "$pw" != "$pw2" ]; then echo "Those did not match." >&2; exit 1; fi
if [ "${#pw}" -lt 12 ]; then echo "That password is under 12 characters. Pick a longer one." >&2; exit 1; fi

# The values travel as environment variables, never spliced into the Python
# source. A password containing a quote, a backslash or a newline would
# otherwise either break the script or silently truncate what gets stored.
AERYX_SLUG="$slug" AERYX_EMAIL="$email" AERYX_ORG="$org" AERYX_NAME="$name" AERYX_PW="$pw" \
compose exec -T \
  -e AERYX_SLUG -e AERYX_EMAIL -e AERYX_ORG -e AERYX_NAME -e AERYX_PW \
  backend python - <<'PYEOF'
import os
from sqlalchemy import select
from app.db import Base, SessionLocal, engine
from app.models import Organization, User
from app.security import hash_password

slug = os.environ["AERYX_SLUG"].strip().lower()
email = os.environ["AERYX_EMAIL"].strip().lower()
org_name = os.environ.get("AERYX_ORG", "").strip() or slug.title()
full_name = os.environ.get("AERYX_NAME", "Administrator").strip()
password = os.environ["AERYX_PW"]

Base.metadata.create_all(bind=engine)
db = SessionLocal()
org = db.scalar(select(Organization).where(Organization.slug == slug))
created_org = False
if org is None:
    org = Organization(slug=slug, name=org_name)
    db.add(org)
    db.flush()
    created_org = True

user = db.scalar(select(User).where(User.org_id == org.id, User.email == email))
if user is not None:
    user.password_hash = hash_password(password)
    user.role = "admin"
    user.is_active = True
    action = "password reset"
else:
    db.add(User(org_id=org.id, email=email, full_name=full_name,
                role="admin", password_hash=hash_password(password)))
    action = "administrator created"
db.commit()

print(("organisation created: " if created_org else "organisation found: ") + slug)
print(action + ": " + email)
print("")
print("Sign in with:")
print("  Company ID: " + slug)
print("  Email:      " + email)
print("  Password:   the one you just set")
PYEOF
echo
echo "Done."
