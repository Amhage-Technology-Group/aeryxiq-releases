# AeryxIQ 1.0.1 On-Premises Edition

A Drone Picture Archiving and Communication System. Drone imagery goes in
as a folder; it comes out as a graded, signed inspection study with every
frame geolocated.

This edition runs entirely on your own hardware. There is no account, no
licence key and no call home. Nothing about your flights, your assets or
your clients leaves the machine you install it on.

An Amhage Technology Group LLC product.

---

## Install

**You need:** Docker Desktop (Windows or macOS) or Docker Engine (Linux),
4 CPU cores, 8 GB of memory, and disk for your imagery: reckon on the size
of your SD cards plus half again.

**Windows**

```
powershell -ExecutionPolicy Bypass -File .\up.ps1
```

**Linux or macOS**

```
./up.sh
```

Add `-WithDemoData` (Windows) or `--with-demo` (Linux) to load sample
content first, four worked scenarios across wind, buildings, agriculture
and public safety. Useful for a look round before your own data goes in.

`up` finds Docker (and on Windows and macOS starts Docker Desktop if it is
not running), moves to a free port if 80 or 443 are already in use, checks
the HTTPS address end to end, opens it in your browser, and offers to create
your first administrator. The address is **https://aeryxiq.localhost**, or
**https://aeryxiq.localhost:8443** if 443 was taken. To create or reset an
administrator later:

```
powershell -ExecutionPolicy Bypass -File .\new-admin.ps1     (Windows)
./new-admin.sh                                               (Linux/macOS)
```

Sign in with three fields: **Company ID** (the short ID you chose for your
organisation), **Email** and **Password**. One installation can hold several
organisations, and no organisation can see another's flights.

**Buy Support** and **Upgrade to Cloud** are in the application's sidebar and
on the sign-in page: support plan $199 a month, professional installation
$499 once, at https://aeryxiq.com/services/

## The certificate warning on the first visit

Expected, and not a mistake. This installation issues its own HTTPS
certificate from a certificate authority created inside it, because
requesting one from the internet would mean the product could not be
installed in a building without a connection. The traffic is encrypted
either way. To make the browser stop asking:

```
powershell -ExecutionPolicy Bypass -File .\trust-certificate.ps1   (as administrator)
sudo ./trust-certificate.sh                                        (Linux)
```

## The scripts

| Script | What it does |
|---|---|
| `up` | Start. On the first run, writes `.env` and generates the secrets |
| `down` | Stop. Your data is in Docker volumes and is untouched |
| `health` | What is running, whether the API answers, disk in use |
| `new-admin` | Create an administrator, or reset one's password |
| `backup` | Database, imagery and `.env` to a directory you choose |
| `trust-certificate` | Install the local certificate authority so the warning stops |
| `open` (Windows) | Open AeryxIQ in the browser at this installation's address |

## Back it up before you need to

```
powershell -ExecutionPolicy Bypass -File .\backup.ps1 -To D:\Backups   (Windows)
./backup.sh /backups/aeryxiq                                           (Linux/macOS)
```

Three files come out and all three are needed: the database, the imagery
archive, and a copy of `.env`. `.env` holds the token signing key and the
database password, so wherever the backups go deserves the same protection
as the imagery.

Restore it once, on a spare machine, before there is anything at stake.
The procedure is in the Administrator Guide. A backup nobody has restored
is a hope.

## Upgrading from 1.0.0

Back up first (see above). Then:

- **Windows installer:** run the new `AeryxIQ-Setup.exe` and choose to update
  in place. Your flights, imagery and settings are kept.
- **This bundle:** unzip it next to the old folder, copy `.env` from the old
  folder into the new one, stop the old installation with `down`, then run
  `up` from the new folder. The data lives in Docker volumes, not in the folder.

From 1.0.1 on, `up` raises `AERYXIQ_VERSION` in `.env` to the version of the
bundle it ships with, so a newer bundle upgrades on its first start. It never
lowers a version you set by hand.

## Changing the address or the ports

Everything adjustable is in `.env`, written from `env.example` on the first
run. If port 80 or 443 is already taken on the machine, set `HTTPS_PORT`
to something free (`8443`, say) and the address becomes
`https://aeryxiq.localhost:8443`.

`APP_HOST` can be any `*.localhost` name with no DNS changes at all. To
reach the installation from other machines on your network, set it to that
machine's name or address and keep `tls internal` in the `Caddyfile`: the
certificate stays self-issued, which is what you want inside a closed site.

## Known limits of this release

- **Each individual upload is capped at 2 GB.** A larger SD-card dump has
  to go in as more than one upload. Flight splitting by EXIF capture time
  works across uploads, so the flights still come out right; it is the
  single-request size that is capped, not the import.
- **The photogrammetry engine is off by default.** DEM and orthophoto
  generation is heavy. Turn it on with `docker compose --profile terrain
  up -d` and set `NODEODM_URL=http://nodeodm:3000` in `.env`, on a machine
  with headroom.
- **Email is unset.** Invitations and password resets are shown on screen
  for the administrator to pass on. Set the `SMTP_*` values in `.env` to
  send them instead.
- **Elevation lookup is unset.** "Pull elevation from the map" needs an
  outbound connection to a public elevation service; with
  `DEM_SERVICE_URL` blank the button is absent rather than broken.
- **Nothing here holds any human certification.** The AI assistance in
  grading and report drafting is assistance. A study is signed by the
  person who signs it.

## Support

Documentation, this release and its checksums: https://github.com/Amhage-Technology-Group/aeryxiq-releases/releases/latest

Support and installation plans: https://aeryxiq.com/services/

Contact: michael.romansky@amhage.com

Report a bug: use **Report a Bug** in the sidebar or on the sign-in page, or open
https://github.com/Amhage-Technology-Group/aeryxiq-releases/issues/new?template=bug_report.yml
Nothing is sent automatically: the link opens the form in your browser and you
decide what goes in it. For anything you would rather not post publicly, email
the address above.

## Licence

The deployment files in this bundle (compose file, Caddyfile, scripts,
installer) are licensed under the Apache License 2.0: see
LICENSE-APACHE-2.0.txt. The AeryxIQ application, which these files download
as container images, is free to install and run for any purpose under the
AeryxIQ On-Premises Licence in LICENSE.txt, and may not be redistributed.

