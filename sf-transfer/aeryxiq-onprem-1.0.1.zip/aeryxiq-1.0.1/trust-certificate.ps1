# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Amhage Technology Group LLC
# Remove the browser certificate warning on this machine.
#
# Must be run as an administrator:
#   right-click PowerShell, Run as administrator, then
#   powershell -ExecutionPolicy Bypass -File .\trust-certificate.ps1
#
# What this does: AeryxIQ signs its own HTTPS certificate with a
# certificate authority created inside this installation, so that nothing
# has to be requested from the internet and the installation works in a
# building with no connection at all. This script copies that authority's
# public certificate into the Windows trusted store, which is what makes
# the browser stop warning. No private key leaves the container, and the
# authority can sign for this installation only.
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot

$admin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) {
    Write-Host "This needs an administrator PowerShell window." -ForegroundColor Red
    Write-Host "Right-click PowerShell, choose Run as administrator, then run it again."
    exit 1
}

$crt = Join-Path $env:TEMP "aeryxiq-root.crt"
cmd /c "docker compose cp caddy:/data/caddy/pki/authorities/local/root.crt ""$crt"" >nul 2>&1"
if (($LASTEXITCODE -ne 0) -or (-not (Test-Path $crt))) {
    Write-Host "Could not read the certificate. Is AeryxIQ running? Try .\up.ps1" -ForegroundColor Red
    exit 1
}

try {
    $result = Import-Certificate -FilePath $crt -CertStoreLocation "Cert:\LocalMachine\Root"
    Write-Host ""
    Write-Host "Installed. Thumbprint: $($result.Thumbprint)" -ForegroundColor Green
    Write-Host "Close every browser window and reopen AeryxIQ; the warning is gone."
    Write-Host ""
    Write-Host "To undo: certlm.msc, Trusted Root Certification Authorities,"
    Write-Host "Certificates, find the entry above and delete it."
} catch {
    Write-Host "Import failed: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
} finally {
    Remove-Item $crt -ErrorAction SilentlyContinue
}
