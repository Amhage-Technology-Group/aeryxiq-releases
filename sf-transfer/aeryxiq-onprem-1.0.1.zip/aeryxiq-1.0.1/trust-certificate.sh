#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Amhage Technology Group LLC
# Remove the browser certificate warning on this machine.
#
#   sudo ./trust-certificate.sh
#
# AeryxIQ signs its own HTTPS certificate with a certificate authority
# created inside this installation, so that nothing has to be requested from
# the internet and the installation works in a building with no connection
# at all. This script copies that authority's public certificate into the
# system trust store, which is what makes the browser stop warning. No
# private key leaves the container, and the authority can sign for this
# installation only.
set -euo pipefail
cd "$(dirname "$0")"

compose() {
  if docker compose version >/dev/null 2>&1; then docker compose "$@"; else docker-compose "$@"; fi
}

tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
compose cp caddy:/data/caddy/pki/authorities/local/root.crt "$tmp/aeryxiq-root.crt"
if [ ! -s "$tmp/aeryxiq-root.crt" ]; then
  echo "Could not read the certificate. Is AeryxIQ running? Try ./up.sh" >&2
  exit 1
fi

if [ "$(id -u)" -ne 0 ]; then
  echo "This needs root to write to the system trust store. Re-run with sudo." >&2
  echo "The certificate itself was read successfully." >&2
  exit 1
fi

if [ -d /usr/local/share/ca-certificates ]; then
  install -m 644 "$tmp/aeryxiq-root.crt" /usr/local/share/ca-certificates/aeryxiq-root.crt
  update-ca-certificates
elif [ -d /etc/pki/ca-trust/source/anchors ]; then
  install -m 644 "$tmp/aeryxiq-root.crt" /etc/pki/ca-trust/source/anchors/aeryxiq-root.crt
  update-ca-trust extract
else
  echo "This distribution's trust store was not recognised. The certificate is" >&2
  echo "at $tmp/aeryxiq-root.crt - copy it out before this script exits." >&2
  exit 1
fi

echo
echo "Installed into the system trust store."
echo
echo "Firefox and Chrome keep their own stores on Linux. If the warning"
echo "persists, import the same certificate through the browser's own"
echo "certificate settings, or simply accept the warning once: the"
echo "connection is encrypted either way."
